<?php
	error_reporting(E_ALL ^ E_NOTICE);
	session_start();
	if (empty($_SESSION['data1'])) {
		header("Location: http://localhost/CST310/index.php");
	}
	
	

?>
<!DOCTYPE html>
<html lang="en">
<head>

	<title> Profile Page</title>
	
	 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device=width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.css"></script>
</head>
<body>


<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#">Profile</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="index.php">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">About Us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link">Contact Us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="login.php">Log Out</a>
  </li>
  
</ul>



	<div class="container text-center">
	<span class="d-block p-2 text-bg-primary">Welcome to the Profile Page,  <?php echo $_SESSION['data3']?>!</span>
	</div>
	
	<div class="d-grid gap-3">
  <div class="p-2 bg-light border"> Email: <?php echo $_SESSION['data1']?></div>
  <div class="p-2 bg-light border">First Name: <?php echo $_SESSION['data3']?></div>
  <div class="p-2 bg-light border">Last Name: <?php echo $_SESSION['data4']?></div>
  <div class="p-2 bg-light border"> Address: <?php echo $_SESSION['data5']?></div>
  <div class="p-2 bg-light border">Phone#: <?php echo $_SESSION['data6']?></div>
  <div class="p-2 bg-light border">Income: <?php echo $_SESSION['data7']?></div>
  <div class="p-2 bg-light border">SSN: <?php echo $_SESSION['data8']?></div>
  <div class="p-2 bg-light border">Currently Enrolled In: <?php echo $_SESSION['data9']?></div>
  <div class="p-2 bg-light border"> Currently Enrolled In: <?php echo $_SESSION['data10']?></div>
 
  
</div>

<form action="update_role.php" method="POST">
    <label for="role">Edit First Course:</label>
    <select id="role" name="role">
		<option value="">No Class</option>
        <option value="Accounting" <?php echo ($_SESSION['data9'] === 'Accounting') ? 'selected' : ''; ?>>Accounting</option>
        <option value="Math" <?php echo ($_SESSION['data9'] === 'Math') ? 'selected' : ''; ?>>Math</option>
        <option value="Webdesign" <?php echo ($_SESSION['data9'] === 'Webdesign') ? 'selected' : ''; ?>>Webdesign</option>
    </select>
    <button type="submit" name="update_role">Update</button>
</form>
<form action="update_data10.php" method="POST">
    <label for="role10">Edit Second Course:</label>
    <select id="role10" name="data10">
		<option value="">No Class</option>
        <option value="Accounting" <?php echo ($_SESSION['data10'] === 'Accounting') ? 'selected' : ''; ?>>Accounting</option>
        <option value="Math" <?php echo ($_SESSION['data10'] === 'Math') ? 'selected' : ''; ?>>Math</option>
        <option value="Webdesign" <?php echo ($_SESSION['data10'] === 'Webdesign') ? 'selected' : ''; ?>>Webdesign</option>
    </select>
    <button type="submit" name="update_data10">Update</button>
</form>



<head>
    <title>Courses Dropdown</title>
</head>
<body>
    <form method="post" action="enroll.php">
        <label for="courseSelect">Join Waitlist:</label>
        <select id="courseSelect" name="course">
            <option value="accounting">Accounting</option>
            <option value="math">Math</option>
            <option value="webdesign">WebDesign</option>
            <option value="bootcamp">Bootcamp</option>
            <option value="waitlist">Join Waitlist Below</option>
        </select>
        <input type="submit" name="enroll" value="Join">
    </form>
</body>



	

	<?php include 'footer.php';?>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
</body>
</html>

