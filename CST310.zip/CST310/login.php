<?php
	error_reporting(E_ALL ^ E_NOTICE);
	session_start();
	session_destroy();
	

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title> Login Page</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device=width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.css"></script>
</head>
<body>

<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#">Log In</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="index.php">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">About Us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link">Contact Us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="registration.php">Registration</a>
  </li>
</ul>
	

	<span class="d-block p-2 text-bg-dark">Welcome to the Login Page</span>
	
	<form action="includes/login.inc.php" method="POST">
	
	<input type="text" name ="email" placeholder = "E-Mail" required>
	<br>
	<input type="text" name ="password" placeholder = "Password" required>
	<br>

	<button type="submit" name="submit">Sign In</button>
	
 </form>
 
	

	<?php require_once 'footer.php';?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
</body>
</html>




