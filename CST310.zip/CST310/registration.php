<?php
	error_reporting(E_ALL ^ E_NOTICE);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title> Registration Page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device=width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.css"></script>
</head>
<body>
	
	<?php include 'master.php';?>

	<div class="container text-center">
		<h1>Welcome to the Registration Page</h1>
	</div>

	<?php include 'footer.php';?>
	
	 <form action="includes/signup.php" method="POST">
	<input type="text" name ="id" placeholder = "ID" required>
	<br>
	<input type="text" name ="email" placeholder = "E-Mail" required>
	<br>
	<input type="text" name ="password" placeholder = "Password" required>
	<br>
	<input type="text" name ="firstName" placeholder = "First Name" required>
	<br>
	<input type="text" name ="lastName" placeholder = "Last Name" required>
	<br>
	<input type="text" name ="address" placeholder = "Address" required>
	<br>
	<input type="text" name ="phone" placeholder = "Phone Number" required>
	<br>
	<input type="text" name ="salary" placeholder = "Annual Income" required>
	<br>
	<input type="text" name ="SSN" placeholder = "SSN" required>
	<br>
	<body>
    <h2>Select one of the following classes below:</h2>
	</body>
	<input type="radio" name="radio1"  value="WebDesign"  />
	<label for="user_type1">Web Design</label>
	<br>
	
	<input type="radio" name="radio1"  value="Math" />
	<label for="user_type2">Math</label>
	
	
 <div>
	<button type="submit" name="submit">Sign up</button>
</div>
	
 </form>

	

	

</body>
</html>

