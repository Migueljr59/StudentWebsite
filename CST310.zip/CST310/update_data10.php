<?php
session_start();

if (isset($_POST['update_data10'])) {
    $newRole1 = $_POST['data10'];

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "employeedatabase";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);


    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $_SESSION['data1'];

    $sql = "UPDATE employeetable SET course2 = '$newRole1' WHERE email = '$email'";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['data10'] = $newRole1; 
        header("Location: profile.php"); 
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
?>
