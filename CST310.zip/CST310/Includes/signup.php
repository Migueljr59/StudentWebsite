<?php
	include_once 'Connection.php';
	
	$id = $_POST['id'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$first = $_POST['firstName'];
	$last = $_POST['lastName'];
	$address = $_POST['address'];
	$phone = $_POST['phone'];
	$salary = $_POST['salary'];
	$ssn = $_POST['SSN'];
	$type = $_POST['radio1'];
	
	$sql = "INSERT INTO employeetable (`id`, `email`, `password`, `firstName`, `lastName`, `address`, `phone`, `salary`, `SSN`, `role`) 
		VALUES ('$id', '$email', '$password', '$first', '$last', '$address', '$phone', '$salary', '$ssn','$type')";
		
	
		
	mysqli_query($conn, $sql);
		
	header("Location: http://localhost/CST310/index.php");
	
