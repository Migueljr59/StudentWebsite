<?php

include_once 'Connection.php';
session_start();

$emailInput = $_POST['email'];
$passwordInput = $_POST['password'];
 $sql = "SELECT * FROM employeetable WHERE email ='$emailInput';";
 
 
 $result = mysqli_query($conn, $sql);
 
 $row = mysqli_fetch_assoc($result);


 //echo $row['email'];
 $fromData1 = $row['email'];
 $fromData2 = $row['password'];
 $fromData3 = $row['firstName'];
 $fromData4 = $row['lastName'];
 $fromData5 = $row['address'];
 $fromData6 = $row['phone'];
 $fromData7 = $row['salary'];
 $fromData8 = $row['SSN'];
 $fromData9 = $row['role'];
 $fromData10 = $row['course2'];
 

 


 if ($emailInput == $fromData1 && $passwordInput == $fromData2) {
	 header("Location: http://localhost/CST310/profile.php");
 }
 else {
	 header("Location: http://localhost/CST310/login.php");
 }
 
$_SESSION['data1'] = $fromData1;
$_SESSION['data2'] = $fromData2;
$_SESSION['data3'] = $fromData3;
$_SESSION['data4'] = $fromData4;
$_SESSION['data5'] = $fromData5;
$_SESSION['data6'] = $fromData6;
$_SESSION['data7'] = $fromData7;
$_SESSION['data8'] = $fromData8;
$_SESSION['data9'] = $fromData9;
$_SESSION['data10'] = $fromData10;

$_SESSION['username'] = $fromData1;
 
 
 
 
 
 
 

	
?>