<?php
session_start();

if (isset($_POST['update_role'])) {
    $newRole = $_POST['role'];



$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";+
$dbName = "employeedatabase";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $_SESSION['data1'];

    $sql = "UPDATE employeetable SET role = '$newRole' WHERE email = '$email'";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['data9'] = $newRole; 
        header("Location: profile.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
?>
